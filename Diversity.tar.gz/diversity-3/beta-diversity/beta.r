#!/usr/bin/env Rscript

# Packages
#install.packages("ggplot2")
library(ggplot2)

# Import
data <- read.table(file = "pcoa-data.txt", header = TRUE, sep = '\t')

group = data$group
colors <- (c("#51a6b0", "#8c386d"))

# Graph
theme_set(theme_bw())
graph <- ggplot(data, aes(x = pcoa1, y = pcoa2)) +
geom_point(aes(col=group, shape = group), size = 3) +
scale_color_manual(values = colors) +
labs(x="PCoA 1 (24.75%)", y="PCoA 2 (21.75%)", title = "ANOSIM = 0.112; p-value = 0.128")

#Graph2
group = data$group
colors2 <- (c("#51a6b0", "#8c386d"))

theme_set(theme_bw())
graph2 <- ggplot(data, aes(x = pcoa1, y = pcoa3)) +
geom_point(aes(col=group, shape = group), size = 3) +
scale_color_manual(values = colors2) +
labs(x="PCoA 1 (24.75%)", y="PCoA 3 (14.36%)", title = "ANOSIM = 0.112; p-value = 0.128")

#Graph3
group = data$group
colors3 <- (c("#51a6b0", "#8c386d"))

theme_set(theme_bw())
graph3 <- ggplot(data, aes(x = pcoa2, y = pcoa3)) +
geom_point(aes(col=group, shape = group), size = 3) +
scale_color_manual(values = colors3) +
labs(x="PCoA 2 (21.75%)", y="PCoA 3 (14.36%)", title = "ANOSIM = 0.112; p-value = 0.128")

# Export
png(filename = "unweighted_bdiv_pcoa1_pcoa2.png")
graph
dev.off()

png(filename = "unweighted_bdiv_pcoa1_pcoa3.png")
graph2
dev.off()

png(filename = "unweighted_bdiv_pcoa2_pcoa3.png")
graph3
dev.off()