#!/usr/bin/env Rscript

# Packages
install.packages("ggplot2")
install.packages("ggpubr")
library(ggplot2)
library(ggpubr)

alpha <- read.delim(file = "shannon.txt", header = TRUE)

colors <- c("#d95dab", "#47d1a1")

p_value <- list(c("gen1", "gen2"))

# Graph 
theme_set(theme_bw())
graph <- ggplot(alpha, aes(x = group, y = shannon)) +
geom_boxplot(aes(color = group)) +
geom_point(aes(color = group), position = position_jitterdodge()) +
scale_color_manual(values = colors) +
theme(legend.position = "none") +
stat_compare_means(comparisons = p_value,
    method = "wilcox.test")

# Export
png(filename = "shannon_boxplot.png")
graph
dev.off()
